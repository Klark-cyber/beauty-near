import { ObjectId } from 'bson';
import { randomUUID } from 'crypto';
import * as path from 'path';
import { T } from './types/common';

// ── SORT OPTIONS ─────────────────────────────────────────────────────────────

export const availableAgentSorts = ['createdAt', 'updatedAt', 'memberLikes', 'memberViews', 'memberRank'];
export const availableMemberSorts = ['createdAt', 'updatedAt', 'memberLikes', 'memberViews'];
export const availableCommentSorts = ['createdAt', 'updatedAt'];
export const availableFaqSorts = ['createdAt', 'updatedAt'];
export const availableNoticeSorts = ['createdAt', 'updatedAt', 'noticeViews'];
export const availableInquirySorts = ['createdAt', 'updatedAt'];
export const availableBoardArticleSorts = ['createdAt', 'updatedAt', 'articleLikes', 'articleViews'];

export const availableSalonSorts = [
    'createdAt', 'updatedAt',
    'salonLikes', 'salonViews', 'salonRank', 'salonFollowers',
];

export const availableServiceSorts = [
    'createdAt', 'updatedAt',
    'serviceLikes', 'serviceViews', 'serviceRank', 'servicePrice', 'serviceRating',
];

export const availableBookingSorts = ['createdAt', 'updatedAt', 'bookingDate'];

// ── IMAGE CONFIGURATION ───────────────────────────────────────────────────────

export const validMimeTypes = ['image/png', 'image/jpg', 'image/jpeg'];

export const getSerialForImage = (filename: string) => {
    const ext = path.parse(filename).ext;
    return randomUUID() + ext;
};

// ── UTILS ─────────────────────────────────────────────────────────────────────

export const shapeIntoMongoObjectId = (target: any) => {
    return typeof target === 'string' ? new ObjectId(target) : target;
};

// ── LOOKUPS ───────────────────────────────────────────────────────────────────

export const lookupAuthMemberLiked = (memberId: T, targetRefId: string = '$_id') => {
    return {
        $lookup: {
            from: 'likes',
            let: {
                localLikeRefId: targetRefId,
                localMemberId: memberId,
                localMyFavorite: true,
            },
            pipeline: [
                {
                    $match: {
                        $expr: {
                            $and: [
                                { $eq: ['$likeRefId', '$$localLikeRefId'] },
                                { $eq: ['$memberId', '$$localMemberId'] },
                            ],
                        },
                    },
                },
                {
                    $project: {
                        _id: 0,
                        memberId: 1,
                        likeRefId: 1,
                        myFavorite: '$$localMyFavorite',
                    },
                },
            ],
            as: 'meLiked',
        },
    };
};

interface LookupAuthMemberFollowed {
    followerId: T;
    followingId: string;
}

export const lookupAuthMemberFollowed = (input: LookupAuthMemberFollowed) => {
    const { followerId, followingId } = input;
    return {
        $lookup: {
            from: 'follows',
            let: {
                localFollowerId: followerId,
                localFollowingId: followingId,
                localMyFavorite: true,
            },
            pipeline: [
                {
                    $match: {
                        $expr: {
                            $and: [
                                { $eq: ['$followerId', '$$localFollowerId'] },
                                { $eq: ['$followingId', '$$localFollowingId'] },
                            ],
                        },
                    },
                },
                {
                    $project: {
                        _id: 0,
                        followerId: 1,
                        followingId: 1,
                        myFollowing: '$$localMyFavorite',
                    },
                },
            ],
            as: 'meFollowed',
        },
    };
};

export const lookupMember = [
    {
        $lookup: {
            from: 'members',
            localField: 'memberId',
            foreignField: '_id',
            as: 'memberData',
        },
    },
];

export const lookupFollowingData = {
    $lookup: {
        from: 'members',
        localField: 'followingId',
        foreignField: '_id',
        as: 'followingData',
    },
};

export const lookupFollowerData = {
    $lookup: {
        from: 'members',
        localField: 'followerId',
        foreignField: '_id',
        as: 'followerData',
    },
};

// ── SALON LOOKUPS ─────────────────────────────────────────────────────────────

export const lookupSalon = [
    {
        $lookup: {
            from: 'salons',
            localField: 'salonId',
            foreignField: '_id',
            as: 'salonData',
        },
    },
];

export const lookupService = [
    {
        $lookup: {
            from: 'services',
            localField: 'serviceId',
            foreignField: '_id',
            as: 'serviceData',
        },
    },
];